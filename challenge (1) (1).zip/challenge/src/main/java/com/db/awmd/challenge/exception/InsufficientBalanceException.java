package com.db.awmd.challenge.exception;

public class InsufficientBalanceException extends RuntimeException {

	public InsufficientBalanceException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
